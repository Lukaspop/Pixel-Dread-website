﻿namespace PixelDread.DTO
{
    public class FileInputModel
    {
        public IFormFile File { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
    }
}
