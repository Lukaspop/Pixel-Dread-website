import { Category } from "../types/category";

export const Blog : Category ={
    id: 1,
    name: "Blog"
}
export const FAQ : Category ={
    id: 2,
    name: "FAQ"
}
export const PatchNotes : Category ={
    id: 3,
    name: "PatchNotes"
}
